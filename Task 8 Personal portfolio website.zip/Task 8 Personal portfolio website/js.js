// Optional Dark Mode
const toggle = document.createElement("button");
toggle.innerText = "🌙";
toggle.style.position = "fixed";
toggle.style.bottom = "1rem";
toggle.style.left = "1rem";
toggle.style.padding = "0.5rem";
toggle.style.background = "#2f80ed";
toggle.style.color = "white";
toggle.style.border = "none";
toggle.style.borderRadius = "50%";
toggle.style.cursor = "pointer";
document.body.appendChild(toggle);

toggle.onclick = () => {
  document.body.classList.toggle("dark");
};
